#ifndef ISL_LOCAL_PRIVATE_H
#define ISL_LOCAL_PRIVATE_H

#include <isl_local.h>

__isl_give isl_local *isl_local_alloc_from_mat(__isl_take isl_mat *mat);

#endif

for (int c0 = 0; c0 <= M; c0 += 1)
  S1(c0);
for (int c0 = 1; c0 <= M; c0 += 1)
  S2(c0);
for (int c0 = 0; c0 <= M; c0 += 1)
  S3(c0);
